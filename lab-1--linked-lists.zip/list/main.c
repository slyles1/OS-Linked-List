#include <stdio.h>
#include "list.h"

int main() {
  printf("Tests for linked list implementation\n");
  list_t *start = list_alloc(2);
  list_print(start);
  list_free(start);
             
  return 0;
}